"""Main modules for the sicore package."""
