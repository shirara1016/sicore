"""Core modules for the sicore package."""
