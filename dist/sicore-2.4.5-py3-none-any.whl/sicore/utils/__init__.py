"""Util functions for the sicore package."""
